"""Storage backend: the interface and the xbmcvfs implementation (NFS/SMB/local).

All access goes through xbmcvfs; there is no file locking. Files are written as <name>.tmp,
read back, then renamed to their final name.
"""

from __future__ import annotations

import posixpath
import time
from typing import Any, Callable, Iterable

import xbmcvfs

LAYOUT = ("events", "devices", "snapshots")
# NFS clients can report a stale size right after a write: read back a few times
READBACK_TRIES = 4
READBACK_WAIT_S = 0.25


class BackendError(Exception):
    """A storage operation failed (network down, file missing, rename refused ...)."""


class Backend:
    """What the sync engine needs from a storage. Replace for e.g. an HTTP backend."""

    folders: tuple[str, ...] = ()

    def ensure_layout(self) -> None:
        raise NotImplementedError

    def list_files(self, folder: str) -> list[str]:
        raise NotImplementedError

    def read_text(self, folder: str, name: str) -> str:
        raise NotImplementedError

    def write_text(self, folder: str, name: str, text: str, overwrite: bool = False) -> None:
        raise NotImplementedError

    def delete(self, folder: str, name: str) -> None:
        raise NotImplementedError

    def mtime(self, folder: str, name: str) -> float:
        raise NotImplementedError

    def probe(self, label: str) -> None:
        """Write, read back and delete a test file in the storage root and in every folder.

        Raise BackendError if that fails. A folder another device created can be read-only for
        this device, so the root alone proves nothing."""
        name = f".probe-{label}.txt"
        for folder in ("", *self.folders):
            self.write_text(folder, name, "watchsync", overwrite=True)
            if self.read_text(folder, name) != "watchsync":
                raise BackendError(f"probe file in {folder or 'the root'} differs")
            self.delete(folder, name)


class VfsBackend(Backend):
    def __init__(
        self,
        root: str,
        folders: Iterable[str] = LAYOUT,
        vfs: Any = xbmcvfs,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.root = root if root.endswith(("/", "\\")) else root + "/"
        self.folders = tuple(folders)
        self.vfs = vfs
        self.sleep = sleep

    def _dir(self, folder: str) -> str:
        return self.root + (folder + "/" if folder else "")

    def _path(self, folder: str, name: str) -> str:
        return self._dir(folder) + name

    def ensure_layout(self) -> None:
        for folder in ("", *self.folders):
            path = self._dir(folder)
            if not self.vfs.exists(path) and not self.vfs.mkdirs(path):
                raise BackendError(f"cannot create {path}")

    def list_files(self, folder: str) -> list[str]:
        path = self._dir(folder)
        if not self.vfs.exists(path):
            raise BackendError(f"{path} not reachable")
        return list(self.vfs.listdir(path)[1])

    def _read_bytes(self, path: str) -> bytes:
        if not self.vfs.exists(path):
            raise BackendError(f"{path} does not exist")
        file = self.vfs.File(path)
        try:
            return bytes(file.readBytes(file.size()))
        finally:
            file.close()

    def read_text(self, folder: str, name: str) -> str:
        try:
            return self._read_bytes(self._path(folder, name)).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise BackendError(f"{name}: not UTF-8") from exc

    def _same_content(self, path: str, data: bytes) -> bool:
        try:
            return self._read_bytes(path) == data
        except BackendError:
            return False

    def _read_back(self, path: str, data: bytes) -> bytes:
        """What a read of the file returns; retried while it differs (stale NFS attributes)."""
        back = b""
        for attempt in range(READBACK_TRIES):
            if attempt:
                self.sleep(READBACK_WAIT_S)
            try:
                back = self._read_bytes(path)
            except BackendError:
                back = b""
            if back == data:
                break
        return back

    def write_text(self, folder: str, name: str, text: str, overwrite: bool = False) -> None:
        data = text.encode("utf-8")
        target = self._path(folder, name)
        tmp = self._path(folder, posixpath.splitext(name)[0] + ".tmp")
        if self.vfs.exists(tmp):
            self.vfs.delete(tmp)
        file = self.vfs.File(tmp, "w")
        try:
            written = file.write(bytearray(data))
        finally:
            file.close()
        if not written:
            self.vfs.delete(tmp)
            raise BackendError(
                f"cannot write {tmp}: the write was refused "
                "(does this device have write permission for the folder on the NAS?)"
            )
        back = self._read_back(tmp, data)
        if back != data:
            self.vfs.delete(tmp)
            raise BackendError(f"cannot write {tmp}: read back {len(back)} of {len(data)} bytes")
        if self.vfs.exists(target):
            if not overwrite:
                same = self._same_content(target, data)
                self.vfs.delete(tmp)
                if same:
                    return
                raise BackendError(f"{target} already exists")
            self.vfs.delete(target)
        if not self.vfs.rename(tmp, target):
            raise BackendError(f"cannot rename {tmp}")

    def delete(self, folder: str, name: str) -> None:
        path = self._path(folder, name)
        if self.vfs.exists(path) and not self.vfs.delete(path):
            raise BackendError(f"cannot delete {path}")

    def mtime(self, folder: str, name: str) -> float:
        try:
            return float(self.vfs.Stat(self._path(folder, name)).st_mtime())
        except Exception as exc:  # noqa: BLE001  (Stat raises various errors)
            raise BackendError(f"cannot stat {name}") from exc


def optional_text(backend: Backend, folder: str, name: str) -> str | None:
    """Text of a file, or None if it is not there."""
    try:
        return backend.read_text(folder, name)
    except BackendError:
        return None
